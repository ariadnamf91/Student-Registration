﻿'Coded by Ariadna Marill
'September 16, 2016


Imports System.Data.SqlClient
Imports System.Data

Public Class Student


    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Dim student_id_new As String

        student_id_new = txtStudent.Text.ToString()


        lblMessage.Text = ""

        Dim date1 As DateTime = Now


        Dim con As New SqlConnection()

        Dim cmd As New SqlCommand()

        'Sign Out
        Dim out As New SqlCommand()

        'Delete from Sign In
        Dim delete_in As New SqlCommand()

        'Reader
        Dim rd As SqlDataReader
        Dim reader As SqlDataReader

        'Sign In
        Dim in1 As New SqlCommand()

        'Check if the student is registered
        Dim isRecord As New SqlCommand()


        If Not IsNumeric(txtStudent.Text) Then

            lblMessage.ForeColor = Color.Red
            lblMessage.Text = "Invalid Format"

        ElseIf txtStudent.TextLength <> 10 Then

            lblMessage.ForeColor = Color.Red
            lblMessage.Text = "Invalid Format"

        End If

        GetId.Student_Num = txtStudent.Text



        ' GetId.Student_Num = Me.txtStudent.Text


        'Setting up the connection

        con.ConnectionString = "Data Source=.;Initial Catalog=STUDENT;Integrated Security=True"


        cmd.Connection = con
        in1.Connection = con
        out.Connection = con
        delete_in.Connection = con
        isRecord.Connection = con

        con.Open()

        cmd.CommandText = "select Student_Id from Sign_In_New where Student_Id = '" + student_id_new + "'"


        'Insert Sign In

        in1.CommandText = "insert into Sign_in_New (Student_Id, Date_Signed_In) values('" + student_id_new + "', '" + date1 + "') "

        'Insert Sign Out

        out.CommandText = "insert into Sign_Out_History_New (Student_Id, Date_Signed_Out) values('" + student_id_new + "', '" + date1 + "') "

        'Delete from Sign In

        delete_in.CommandText = "delete from Sign_In_New where Student_Id = '" + student_id_new + "'"

        'Check if it is registered
        isRecord.CommandText = "select Student_Id from Register_New where Student_Id = '" + student_id_new + "'"



        'try to check if the student exists in Sign_in

        Try


            '  Dim rd As SqlDataReader = isRecord.ExecuteReader

            rd = cmd.ExecuteReader


            'Check if the student is in Sign In

            If rd.HasRows = True Then
                rd.Close()
                out.ExecuteNonQuery()
                delete_in.ExecuteNonQuery()
                txtStudent.Clear()
                lblMessage.ForeColor = Color.Red
                lblMessage.Text = "Student Signed Out"

            ElseIf rd.HasRows = False Then
                rd.Close()
                reader = isRecord.ExecuteReader

                If reader.HasRows = True Then
                    reader.Close()
                    in1.ExecuteNonQuery()
                    txtStudent.Clear()
                    lblMessage.ForeColor = Color.Green
                    lblMessage.Text = "Student Signed In"

                ElseIf reader.HasRows = False Then
                    reader.Close()

                    If lblMessage.Text = "Invalid Format" Then

                        txtStudent.Clear()

                    Else

                        Register_New.Show()
                        txtStudent.Clear()
                        lblMessage.Text = ""

                    End If



                End If


            End If
            con.Close()

        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)

        End Try


    End Sub




    Private Sub btnSaveOld_Click(sender As Object, e As EventArgs) Handles btnSaveOld.Click

        Dim student_id_old As String

        student_id_old = txtStudentOld.Text.ToString()

        lblMessage.Text = ""

        Dim date1 As DateTime = Now


        Dim con As New SqlConnection()

        Dim cmd As New SqlCommand()

        'Sign Out
        Dim out As New SqlCommand()

        'Delete from Sign In
        Dim delete_in As New SqlCommand()

        'Reader
        Dim rd As SqlDataReader
        Dim reader As SqlDataReader

        'Sign In
        Dim in1 As New SqlCommand()

        'Check if the student is registered
        Dim isRecord As New SqlCommand()

        Dim text As String

        text = txtStudentOld.Text

        If text.Length <> 9 Then

            lblMessage.ForeColor = Color.Red
            lblMessage.Text = "Invalid Format"
            txtStudentOld.Clear()


        ElseIf IsNumeric(text.Substring(0)) Then
            lblMessage.ForeColor = Color.Red
            lblMessage.Text = "Invalid Format"
            txtStudentOld.Clear()


        ElseIf Not IsNumeric(text.Substring(1, 8)) Then
            lblMessage.ForeColor = Color.Red
            lblMessage.Text = "Invalid Format"
            txtStudentOld.Clear()


        Else


            GetId.Student_Num = text.ToString




            'Setting up the connection

            con.ConnectionString = "Data Source=.;Initial Catalog=STUDENT;Integrated Security=True"


            cmd.Connection = con
            in1.Connection = con
            out.Connection = con
            delete_in.Connection = con
            isRecord.Connection = con

            con.Open()

            cmd.CommandText = "select Student_Id from Sign_In_Old where Student_Id = '" + student_id_old + "'"


            'Insert Sign In

            in1.CommandText = "insert into Sign_in_Old (Student_Id, Date_Signed_In) values('" + student_id_old + "', '" + date1 + "') "

            'Insert Sign Out

            out.CommandText = "insert into Sign_Out_History_Old (Student_Id, Date_Signed_Out) values('" + student_id_old + "', '" + date1 + "') "

            'Delete from Sign In

            delete_in.CommandText = "delete from Sign_In_Old where Student_Id = '" + student_id_old + "'"

            'Check if it is registered
            isRecord.CommandText = "select Student_Id from Register_Old where Student_Id = '" + student_id_old + "'"



            'try to check if the student exists in Sign_in

            Try


                '  Dim rd As SqlDataReader = isRecord.ExecuteReader

                rd = cmd.ExecuteReader


                'Check if the student is in Sign In

                If rd.HasRows = True Then
                    rd.Close()
                    out.ExecuteNonQuery()
                    delete_in.ExecuteNonQuery()
                    txtStudentOld.Clear()
                    lblMessage.ForeColor = Color.Red
                    lblMessage.Text = "Student Signed Out"

                ElseIf rd.HasRows = False Then
                    rd.Close()
                    reader = isRecord.ExecuteReader

                    If reader.HasRows = True Then
                        reader.Close()
                        in1.ExecuteNonQuery()
                        txtStudentOld.Clear()
                        lblMessage.ForeColor = Color.Green
                        lblMessage.Text = "Student Signed In"

                    ElseIf reader.HasRows = False Then
                        reader.Close()

                        If lblMessage.Text = "Invalid Format" Then

                            txtStudentOld.Clear()

                        Else

                            Register_Former.Show()
                            txtStudentOld.Clear()
                            lblMessage.Text = ""

                        End If



                    End If


                End If
                con.Close()

            Catch ex As System.Exception
                System.Windows.Forms.MessageBox.Show(ex.Message)

            End Try

        End If

        'End If
    End Sub

End Class
