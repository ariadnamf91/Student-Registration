﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Register_New
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Register_New))
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.lbl_Semester = New System.Windows.Forms.Label()
        Me.txtSemester = New System.Windows.Forms.TextBox()
        Me.lbl_Instructor = New System.Windows.Forms.Label()
        Me.txtInstructor = New System.Windows.Forms.TextBox()
        Me.lbl_Course = New System.Windows.Forms.Label()
        Me.txtCourse = New System.Windows.Forms.TextBox()
        Me.lbl_Name = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.lbl_ID = New System.Windows.Forms.Label()
        Me.txtStudent = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblMessage
        '
        Me.lblMessage.AutoSize = True
        Me.lblMessage.Location = New System.Drawing.Point(168, 293)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(0, 13)
        Me.lblMessage.TabIndex = 34
        '
        'lbl_Semester
        '
        Me.lbl_Semester.AutoSize = True
        Me.lbl_Semester.Location = New System.Drawing.Point(70, 251)
        Me.lbl_Semester.Name = "lbl_Semester"
        Me.lbl_Semester.Size = New System.Drawing.Size(69, 13)
        Me.lbl_Semester.TabIndex = 33
        Me.lbl_Semester.Text = "SEMESTER:"
        '
        'txtSemester
        '
        Me.txtSemester.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSemester.Location = New System.Drawing.Point(171, 248)
        Me.txtSemester.Name = "txtSemester"
        Me.txtSemester.Size = New System.Drawing.Size(144, 20)
        Me.txtSemester.TabIndex = 32
        '
        'lbl_Instructor
        '
        Me.lbl_Instructor.AutoSize = True
        Me.lbl_Instructor.Location = New System.Drawing.Point(70, 215)
        Me.lbl_Instructor.Name = "lbl_Instructor"
        Me.lbl_Instructor.Size = New System.Drawing.Size(81, 13)
        Me.lbl_Instructor.TabIndex = 31
        Me.lbl_Instructor.Text = "INSTRUCTOR:"
        '
        'txtInstructor
        '
        Me.txtInstructor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtInstructor.Location = New System.Drawing.Point(171, 212)
        Me.txtInstructor.Name = "txtInstructor"
        Me.txtInstructor.Size = New System.Drawing.Size(144, 20)
        Me.txtInstructor.TabIndex = 30
        '
        'lbl_Course
        '
        Me.lbl_Course.AutoSize = True
        Me.lbl_Course.Location = New System.Drawing.Point(70, 179)
        Me.lbl_Course.Name = "lbl_Course"
        Me.lbl_Course.Size = New System.Drawing.Size(69, 13)
        Me.lbl_Course.TabIndex = 29
        Me.lbl_Course.Text = "COURSE ID:"
        '
        'txtCourse
        '
        Me.txtCourse.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCourse.Location = New System.Drawing.Point(171, 176)
        Me.txtCourse.Name = "txtCourse"
        Me.txtCourse.Size = New System.Drawing.Size(144, 20)
        Me.txtCourse.TabIndex = 28
        '
        'lbl_Name
        '
        Me.lbl_Name.AutoSize = True
        Me.lbl_Name.Location = New System.Drawing.Point(70, 143)
        Me.lbl_Name.Name = "lbl_Name"
        Me.lbl_Name.Size = New System.Drawing.Size(41, 13)
        Me.lbl_Name.TabIndex = 27
        Me.lbl_Name.Text = "NAME:"
        '
        'txtName
        '
        Me.txtName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtName.Location = New System.Drawing.Point(171, 140)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(144, 20)
        Me.txtName.TabIndex = 26
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.SystemColors.Control
        Me.btnSave.Location = New System.Drawing.Point(347, 102)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(89, 23)
        Me.btnSave.TabIndex = 25
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'lbl_ID
        '
        Me.lbl_ID.AutoSize = True
        Me.lbl_ID.Location = New System.Drawing.Point(70, 107)
        Me.lbl_ID.Name = "lbl_ID"
        Me.lbl_ID.Size = New System.Drawing.Size(76, 13)
        Me.lbl_ID.TabIndex = 24
        Me.lbl_ID.Text = "STUDENT ID:"
        '
        'txtStudent
        '
        Me.txtStudent.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStudent.Location = New System.Drawing.Point(171, 104)
        Me.txtStudent.Name = "txtStudent"
        Me.txtStudent.Size = New System.Drawing.Size(144, 20)
        Me.txtStudent.TabIndex = 23
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(185, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(243, 24)
        Me.Label1.TabIndex = 50
        Me.Label1.Text = "STUDENT WITH NEW ID"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(57, 11)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 72)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 49
        Me.PictureBox1.TabStop = False
        '
        'Register_New
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(517, 328)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.lbl_Semester)
        Me.Controls.Add(Me.txtSemester)
        Me.Controls.Add(Me.lbl_Instructor)
        Me.Controls.Add(Me.txtInstructor)
        Me.Controls.Add(Me.lbl_Course)
        Me.Controls.Add(Me.txtCourse)
        Me.Controls.Add(Me.lbl_Name)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.lbl_ID)
        Me.Controls.Add(Me.txtStudent)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "Register_New"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Register New ID"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMessage As Label
    Friend WithEvents lbl_Semester As Label
    Friend WithEvents txtSemester As TextBox
    Friend WithEvents lbl_Instructor As Label
    Friend WithEvents txtInstructor As TextBox
    Friend WithEvents lbl_Course As Label
    Friend WithEvents txtCourse As TextBox
    Friend WithEvents lbl_Name As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents btnSave As Button
    Friend WithEvents lbl_ID As Label
    Friend WithEvents txtStudent As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
