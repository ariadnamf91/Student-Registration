﻿Public Class GetId

    Public Shared Student_Num As String = ""


End Class
