﻿'Coded by Ariadna Marill
'December 22, 2016

Imports System.Data.SqlClient


Public Class Register_New

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Dim date1 As DateTime = Now

        Dim con As New SqlConnection()

        'Register a student
        Dim register As New SqlCommand()

        con.ConnectionString = "Data Source=.;Initial Catalog=STUDENT;Integrated Security=True"

        register.Connection = con

        con.Open()


        Try

            If Not IsNumeric(txtStudent.Text) Then

                lblMessage.ForeColor = Color.Red
                lblMessage.Text = "Invalid Format"

            ElseIf txtStudent.TextLength <> 10 Then

                lblMessage.ForeColor = Color.Red
                lblMessage.Text = "Invalid Format"

            End If


            register.CommandText = "insert into REGISTER_NEW (STUDENT_ID, STUDENT_NAME, CLASS_CODE, PROFESSOR_NAME, TERM, Date_Registered) values(" + txtStudent.Text + ", '" + txtName.Text + "', '" + txtCourse.Text + "', '" + txtInstructor.Text + "', '" + txtSemester.Text + "', '" + date1 + "') "
            register.ExecuteNonQuery()

            con.Close()


        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)

        End Try

        Me.Close()

    End Sub

    Private Sub Register_New_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        txtStudent.Text = GetId.Student_Num
        txtStudent.Enabled = False

    End Sub
End Class