﻿Imports System.Data.SqlClient

Public Class Register_Former

    Private Sub btnSave1_Click(sender As Object, e As EventArgs) Handles btnSave1.Click
        Dim date1 As DateTime = Now

        Dim con As New SqlConnection()

        'Register a student
        Dim register As New SqlCommand()

        con.ConnectionString = "Data Source=.;Initial Catalog=STUDENT;Integrated Security=True"

        register.Connection = con

        con.Open()


        Try

            If txtStudent1.TextLength <> 9 Then

                lblMessage1.ForeColor = Color.Red
                lblMessage1.Text = "Invalid Format"

            End If


            register.CommandText = "insert into REGISTER_OLD (STUDENT_ID, STUDENT_NAME, CLASS_CODE, PROFESSOR_NAME, TERM, Date_Registered) values('" + txtStudent1.Text + "', '" + txtName1.Text + "', '" + txtCourse1.Text + "', '" + txtInstructor1.Text + "', '" + txtSemester1.Text + "', '" + date1 + "') "
            register.ExecuteNonQuery()

            con.Close()


        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)

        End Try

        Me.Close()


    End Sub

    Private Sub Register_Former_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtStudent1.Text = GetId.Student_Num
        txtStudent1.Enabled = False
    End Sub
End Class