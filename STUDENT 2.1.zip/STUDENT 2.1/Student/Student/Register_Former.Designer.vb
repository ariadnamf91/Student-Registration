﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Register_Former
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Register_Former))
        Me.lblMessage1 = New System.Windows.Forms.Label()
        Me.lbl_Semester = New System.Windows.Forms.Label()
        Me.txtSemester1 = New System.Windows.Forms.TextBox()
        Me.lbl_Instructor = New System.Windows.Forms.Label()
        Me.txtInstructor1 = New System.Windows.Forms.TextBox()
        Me.lbl_Course = New System.Windows.Forms.Label()
        Me.txtCourse1 = New System.Windows.Forms.TextBox()
        Me.lbl_Name = New System.Windows.Forms.Label()
        Me.txtName1 = New System.Windows.Forms.TextBox()
        Me.btnSave1 = New System.Windows.Forms.Button()
        Me.lbl_ID = New System.Windows.Forms.Label()
        Me.txtStudent1 = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblMessage1
        '
        Me.lblMessage1.AutoSize = True
        Me.lblMessage1.Location = New System.Drawing.Point(168, 293)
        Me.lblMessage1.Name = "lblMessage1"
        Me.lblMessage1.Size = New System.Drawing.Size(0, 13)
        Me.lblMessage1.TabIndex = 46
        '
        'lbl_Semester
        '
        Me.lbl_Semester.AutoSize = True
        Me.lbl_Semester.Location = New System.Drawing.Point(70, 251)
        Me.lbl_Semester.Name = "lbl_Semester"
        Me.lbl_Semester.Size = New System.Drawing.Size(69, 13)
        Me.lbl_Semester.TabIndex = 45
        Me.lbl_Semester.Text = "SEMESTER:"
        '
        'txtSemester1
        '
        Me.txtSemester1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSemester1.Location = New System.Drawing.Point(171, 248)
        Me.txtSemester1.Name = "txtSemester1"
        Me.txtSemester1.Size = New System.Drawing.Size(144, 20)
        Me.txtSemester1.TabIndex = 44
        '
        'lbl_Instructor
        '
        Me.lbl_Instructor.AutoSize = True
        Me.lbl_Instructor.Location = New System.Drawing.Point(70, 215)
        Me.lbl_Instructor.Name = "lbl_Instructor"
        Me.lbl_Instructor.Size = New System.Drawing.Size(81, 13)
        Me.lbl_Instructor.TabIndex = 43
        Me.lbl_Instructor.Text = "INSTRUCTOR:"
        '
        'txtInstructor1
        '
        Me.txtInstructor1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtInstructor1.Location = New System.Drawing.Point(171, 212)
        Me.txtInstructor1.Name = "txtInstructor1"
        Me.txtInstructor1.Size = New System.Drawing.Size(144, 20)
        Me.txtInstructor1.TabIndex = 42
        '
        'lbl_Course
        '
        Me.lbl_Course.AutoSize = True
        Me.lbl_Course.Location = New System.Drawing.Point(70, 179)
        Me.lbl_Course.Name = "lbl_Course"
        Me.lbl_Course.Size = New System.Drawing.Size(69, 13)
        Me.lbl_Course.TabIndex = 41
        Me.lbl_Course.Text = "COURSE ID:"
        '
        'txtCourse1
        '
        Me.txtCourse1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCourse1.Location = New System.Drawing.Point(171, 176)
        Me.txtCourse1.Name = "txtCourse1"
        Me.txtCourse1.Size = New System.Drawing.Size(144, 20)
        Me.txtCourse1.TabIndex = 40
        '
        'lbl_Name
        '
        Me.lbl_Name.AutoSize = True
        Me.lbl_Name.Location = New System.Drawing.Point(70, 143)
        Me.lbl_Name.Name = "lbl_Name"
        Me.lbl_Name.Size = New System.Drawing.Size(41, 13)
        Me.lbl_Name.TabIndex = 39
        Me.lbl_Name.Text = "NAME:"
        '
        'txtName1
        '
        Me.txtName1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtName1.Location = New System.Drawing.Point(171, 140)
        Me.txtName1.Name = "txtName1"
        Me.txtName1.Size = New System.Drawing.Size(144, 20)
        Me.txtName1.TabIndex = 38
        '
        'btnSave1
        '
        Me.btnSave1.BackColor = System.Drawing.SystemColors.Control
        Me.btnSave1.Location = New System.Drawing.Point(347, 102)
        Me.btnSave1.Name = "btnSave1"
        Me.btnSave1.Size = New System.Drawing.Size(89, 23)
        Me.btnSave1.TabIndex = 37
        Me.btnSave1.Text = "Save"
        Me.btnSave1.UseVisualStyleBackColor = False
        '
        'lbl_ID
        '
        Me.lbl_ID.AutoSize = True
        Me.lbl_ID.Location = New System.Drawing.Point(70, 107)
        Me.lbl_ID.Name = "lbl_ID"
        Me.lbl_ID.Size = New System.Drawing.Size(76, 13)
        Me.lbl_ID.TabIndex = 36
        Me.lbl_ID.Text = "STUDENT ID:"
        '
        'txtStudent1
        '
        Me.txtStudent1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStudent1.Location = New System.Drawing.Point(171, 104)
        Me.txtStudent1.Name = "txtStudent1"
        Me.txtStudent1.Size = New System.Drawing.Size(144, 20)
        Me.txtStudent1.TabIndex = 35
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(57, 11)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 72)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 47
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(185, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(236, 24)
        Me.Label1.TabIndex = 48
        Me.Label1.Text = "STUDENT WITH OLD ID"
        '
        'Register_Former
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(517, 328)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblMessage1)
        Me.Controls.Add(Me.lbl_Semester)
        Me.Controls.Add(Me.txtSemester1)
        Me.Controls.Add(Me.lbl_Instructor)
        Me.Controls.Add(Me.txtInstructor1)
        Me.Controls.Add(Me.lbl_Course)
        Me.Controls.Add(Me.txtCourse1)
        Me.Controls.Add(Me.lbl_Name)
        Me.Controls.Add(Me.txtName1)
        Me.Controls.Add(Me.btnSave1)
        Me.Controls.Add(Me.lbl_ID)
        Me.Controls.Add(Me.txtStudent1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "Register_Former"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Register_Former"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMessage1 As Label
    Friend WithEvents lbl_Semester As Label
    Friend WithEvents txtSemester1 As TextBox
    Friend WithEvents lbl_Instructor As Label
    Friend WithEvents txtInstructor1 As TextBox
    Friend WithEvents lbl_Course As Label
    Friend WithEvents txtCourse1 As TextBox
    Friend WithEvents lbl_Name As Label
    Friend WithEvents txtName1 As TextBox
    Friend WithEvents btnSave1 As Button
    Friend WithEvents lbl_ID As Label
    Friend WithEvents txtStudent1 As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
End Class
