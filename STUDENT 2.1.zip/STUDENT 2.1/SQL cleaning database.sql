use [STUDENT]

/*CLEANING TABLES*/
/*	CLEAN NEW*/
delete [dbo].[REGISTER_NEW]
delete [dbo].[SIGN_IN_HISTORY_NEW]
delete [dbo].[SIGN_IN_NEW]
delete [dbo].[SIGN_OUT_HISTORY_NEW]


delete [dbo].[REGISTER_OLD]
delete [dbo].[SIGN_IN_HISTORY_OLD]
delete [dbo].[SIGN_IN_OLD]
delete [dbo].[SIGN_OUT_HISTORY_OLD]






/*DELETING TABLES!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/
/*CAREFULL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

drop table  [dbo].[REGISTER_NEW]
drop table  [dbo].[SIGN_IN_HISTORY_NEW]
drop table  [dbo].[SIGN_IN_NEW]
drop table  [dbo].[SIGN_OUT_HISTORY_NEW]

drop table  [dbo].[REGISTER_OLD]
drop table  [dbo].[SIGN_IN_HISTORY_OLD]
drop table  [dbo].[SIGN_IN_OLD]
drop table  [dbo].[SIGN_OUT_HISTORY_OLD]